var canvas = document.getElementById('screen');
var background = new Image();
background.src = './assets/Menu.png';

var game = new Game(canvas, update, render);
var player = new Player({ x: 15, y: 240 });
var rock = new Rock();

window.onkeydown = function (event) {
            switch (event.keyCode) {
                //up
                case 38:
                case 87:
                        player.y -= 4;
                        player.ay = player.y + 15;
                        player.aY = player.y + 60;
                    break;
                    //left
                case 37:
                case 65:
                        player.x -= 4;
                        player.ax = player.x;
                        player.aX = player.x + 55;                 
                    break;
                    //right
                case 39:
                case 68:
                    player.x += 4;
                    player.ax = player.x;
                    player.aX = player.x + 55;
                    break;
                    //down
                case 40:
                case 83:
                        player.y += 4;
                        player.ay = player.y + 15;
                        player.aY = player.y + 60;
                    break;
            }
   }
		
function update(elapsedTime)
{

}

function render(elapsedTime, ctx)
{
	ctx.clearRect(0, 0, game.HEIGHT, game.WIDTH);
    ctx.drawImage(background, 0, 0, 960, 500);
	
	
	rock.render(elapsedTime, ctx);
	player.render(elapsedTime, ctx);
}

function Player(position) {

  this.x = position.x;
  this.y = position.y;
  this.width  = 63;
  this.height = 63;
  this.spritesheet  = new Image();
  this.spritesheet.src = encodeURI('assets/PlayerSprite.png');
  
  //Adjusted position properties used for collision detection
  this.ax = position.x;
  this.ay = position.y + 15;
  this.aX = position.x + 55;
  this.aY = position.y + 60;
}

Player.prototype.update = function (time) {
	
}

Player.prototype.render = function(time, ctx) {
	ctx.save();
	ctx.drawImage(
       this.spritesheet,
       65, 0, this.width, this.height, this.x, this.y, this.width, this.height);
	   ctx.restore();
}

function Rock()
{
	this.rockImage = new Image();
	this.rockImage.src = 'assets/boulder.png';
}

Rock.prototype.render = function(time,ctx)
{
	ctx.save();
	ctx.drawImage(this.rockImage, 250,250);
}


function Game(screen, updateFunction, renderFunction) {
  this.update = updateFunction;
  this.render = renderFunction;

   //Height/Width
  this.HEIGHT = screen.height;
  this.WIDTH = screen.width;

  // Set up buffers
  this.frontBuffer = screen;
  this.frontCtx = screen.getContext('2d');
  this.backBuffer = document.createElement('canvas');
  this.backBuffer.width = screen.width;
  this.backBuffer.height = screen.height;
  this.backCtx = this.backBuffer.getContext('2d');

  // Start the game loop
  this.oldTime = performance.now();
  this.paused = false;

}

Game.prototype.loop = function(newTime) {
  var game = this;
  var elapsedTime = newTime - this.oldTime;
  this.oldTime = newTime;

  if (!this.paused) this.update(elapsedTime);

  this.render(elapsedTime, this.frontCtx);

  // Flip the back buffer
  this.frontCtx.drawImage(this.backBuffer, 0, 0);
}

var masterLoop = function (timestamp) {
        game.loop(timestamp);
        window.requestAnimationFrame(masterLoop);
}
masterLoop(performance.now());